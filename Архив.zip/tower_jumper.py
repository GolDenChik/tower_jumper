import random

import pygame
from screeninfo import get_monitors
for monitor in get_monitors():
    monx = monitor.width
    mony = monitor.height

pygame.init()

knight_x, knight_y = 200, 400
direction_k = 'l'
menu = True
at = False
anim = 0
attack = 0
clock = pygame.time.Clock()

bg = []
upp = 0

game = True

bolt = pygame.mixer.Sound('music/molniya-shumnyii-blizkii-aktivnyii.mp3')
rain = pygame.mixer.Sound('music/sezon-obilnyih-prolivnyih-dojdey.mp3')
step = pygame.mixer.Sound('music/korotkiy-gluhoy-zvuk-hodbyi-po-jeleznoy-lestnitse.mp3')
miss = pygame.mixer.Sound('music/promah-pri-boe-na-mechah.mp3')
miss.set_volume(0.3)
step.set_volume(1.3)
step_count = 0

screen = pygame.display.set_mode((monx, mony), pygame.FULLSCREEN)
stand_left = pygame.image.load("sprites/knight/idol/left/knight_standing(left).png").convert_alpha()
stand_left = pygame.transform.scale(stand_left, (160, 160))
stand_right = pygame.image.load("sprites/knight/idol/right/knight_standing(right).png").convert_alpha()
stand_right = pygame.transform.scale(stand_right, (160, 160))
fall_left = pygame.image.load("sprites/knight/falling/left/knight_falling(left).png").convert_alpha()
fall_left = pygame.transform.scale(fall_left, (160, 160))
fall_right = pygame.image.load("sprites/knight/falling/right/knight_falling(right).png").convert_alpha()
fall_right = pygame.transform.scale(fall_right, (160, 160))
logo = pygame.image.load("sprites/tower_jumper_logo.gif")
escape_logo = pygame.image.load("sprites/escape.png").convert_alpha()
bg_s = []
walk_left = []
walk_right = []
attack_left = []
attack_right = []
logo = []
logo_anim = 1

for i in range(1, 9):
    walk_left.append(pygame.transform.scale(pygame.image.load(f"sprites/knight/walk/left/knight_walking(left){i}.png"),
                                            (160, 160)))
    walk_right.append(pygame.transform.scale(pygame.image.load(f"sprites/knight/walk/right/knight_walking(right){i}."
                                                               f"png"), (160, 160)))
for i in range(1, 11):
    attack_left.append((pygame.transform.scale(pygame.image.load(f"sprites/knight/attack/left/knight_attack(left){i}."
                                                                 f"png"), (160, 160))))
    attack_right.append((pygame.transform.scale(pygame.image.load(f"sprites/knight/attack/right/knight_attack(right){i}"
                                                                  f".png"), (160, 160))))
    logo.append((pygame.transform.scale(pygame.image.load(f"sprites/logo/tower_jumper_logo{i}.png"),
                                        (monx, mony))))
for i in range(1, 8):
    bg_s.append(pygame.transform.scale(pygame.image.load(f"sprites/bg/wall{i}.png"), (160, 160)))

bg_s.append(pygame.transform.scale(pygame.image.load(f"sprites/bg/wall{1}.png"), (160, 160)))
bg_s.append(pygame.transform.scale(pygame.image.load(f"sprites/bg/wall{2}.png"), (160, 160)))
bg_s.append(pygame.transform.scale(pygame.image.load(f"sprites/bg/wall{5}.png"), (160, 160)))
bg_s.append(pygame.transform.scale(pygame.image.load(f"sprites/bg/wall{6}.png"), (160, 160)))
bg_s.append(pygame.transform.scale(pygame.image.load(f"sprites/bg/wall{8}.png"), (160, 160)))


class knight():
    def __init__(self, anim, attack):
        self.anim = anim
        self.attack = attack

    def move(self):
        global knight_x, direction_k, knight_y, upp, step_count
        if upp != 0:
            pass

        if (keys[pygame.K_LEFT] or keys[pygame.K_a]) and (not keys[pygame.K_RIGHT] and not keys[pygame.K_d]):
            knight_x -= 20
            screen.blit(walk_left[self.anim], (knight_x, knight_y))
            direction_k = 'l'
            if step_count == 0:
                step.play()
            elif step_count == 4:
                step_count = -1
            step_count += 1

        if (not keys[pygame.K_LEFT] and not keys[pygame.K_a]) and (keys[pygame.K_RIGHT] or keys[pygame.K_d]):
            knight_x += 20
            screen.blit(walk_right[self.anim], (knight_x, knight_y))
            direction_k = 'r'
            if step_count == 0:
                step.play()
            elif step_count == 4:
                step_count = -1
            step_count += 1


        if ((not keys[pygame.K_LEFT] and not keys[pygame.K_a] and not keys[pygame.K_RIGHT] and not keys[pygame.K_d]) or
                ((keys[pygame.K_LEFT] or keys[pygame.K_a]) and (keys[pygame.K_RIGHT] or keys[pygame.K_d]))):
            step_count = -1
            if direction_k == 'l':
                screen.blit(stand_left, (knight_x, knight_y))
            if direction_k == 'r':
                screen.blit(stand_right, (knight_x, knight_y))

    def attacking(self):
        global at, knight_x, knight_y, direction_k
        if keys[pygame.K_z] or keys[pygame.K_SPACE]:
            at = True

    def create_bagraund(self):
        global bg
        bg = []
        for i in range(0, 1800, 160):
            for z in range(0, 4000, 160):
                bg.append((random.choice(bg_s), i, z))

    def bagraund(self):
        global bg
        for i in range(len(bg)):
            screen.blit(bg[i][0], (bg[i][1], bg[i][2]))


ng = 0
rain.play(-1)
bolt.play()
while game:
    keys = pygame.key.get_pressed()
    screen.fill('black')
    if menu:
        clock.tick(16)
        if logo_anim != 0 and logo_anim < 9:
            logo_anim += 1
        else:
            logo_anim = 0
        if (random.randrange(0, 450) == 0 and logo_anim == 0) or (keys[pygame.K_z] and keys[pygame.K_w]
                                                                  and keys[pygame.K_LEFT]):
            logo_anim += 1
            bolt.play()
        screen.blit(logo[logo_anim], (0, 0))
        if keys[pygame.K_SPACE]:
            menu = False
    else:
        rain.stop()
        bolt.stop()
        clock.tick(30)
        if anim == 7:
            anim = 0
        else:
            anim += 1

        knight_ = knight(anim, attack)
        if ng == 0:
            knight_.create_bagraund()
            ng = 1

        knight_.bagraund()

        if not at:
            knight_.move()

        if at:
            attack += 1
            if direction_k == 'l':
                screen.blit(attack_left[attack], (knight_x, knight_y))
            elif direction_k == 'r':
                screen.blit(attack_right[attack], (knight_x, knight_y))
        if attack == 1:
            miss.play()
        if attack == 9:
            attack = 0
            at = False

        knight_.attacking()
    screen.blit(escape_logo, (0, 0))
    pygame.display.update()
    for event in pygame.event.get():
        if event.type == pygame.QUIT or keys[pygame.K_ESCAPE]:
            pygame.quit()
